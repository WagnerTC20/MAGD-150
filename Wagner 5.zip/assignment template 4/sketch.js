var x;
var offset = 10
var radius = 100

// left rectangle
var a = 50
var b = 100
var w = 100
var h = 200

// right rectangle
var aa = 650

// right rectangle

function setup() {
  createCanvas(800, 400);
  
  ellipseMode(RADIUS)
  
  x = width/2
}

function draw() {
  background(200);
  
  fill(0, 0, 0) 
  rect(225, 50, 350, 300) 
  line(225, 350, 175, 400)
  line(575, 350, 625, 400)
  // if cursor is within circle
  var d = dist(mouseX, mouseY, 400, 200)
  if (d < radius) {
    radius++;
    
    fill (255, 0, 0)
  } else {
    fill(255, 255, 255,)
  }
  
  // if cursor is on the right half
  if (mouseX > x) {
    x += 0.5;
    offset = -10;
  }
  
  // if cursor is on the left half
  if (mouseX < x) {
    x -= 0.5;
    offset = 10;
  }
  
  // if cursor is within left rectangle
  if ((mouseX > a) && (mouseX < a+w) && (mouseY > b) && (mouseY < b+h)) {
    fill(255, 255, 0)
  }
  
  // if cursor is within left rectangle and mouse is pressed
  if ((mouseX > a) && (mouseX < a+w) && (mouseY > b) && (mouseY < b+h) && (mouseIsPressed == true)) {
    radius = 100
    fill (0, 255, 0);
  } 
  
  // if cursor is within right rectangle
  if ((mouseX >aa) && (mouseX <aa+w) && (mouseY > b) && (mouseY < b+h)) {
    fill(255, 255, 0)
  }
  
  // if cursor is within right rectangle and 'x' is pressed
  if ((mouseX >aa) && (mouseX <aa+w) && (mouseY > b) && (mouseY < b+h) && (keyIsPressed)) {
    if (key == 'x') {
      radius = 100
      fill(0, 255, 0)
    }
  }
  
  line (x, 0, x, height);
  
  // arrow that follows cursor
  line (pmouseX, pmouseY, pmouseX + offset, pmouseY - 10);
  line(pmouseX, pmouseY, pmouseX + offset, pmouseY +10);
  line(pmouseX, pmouseY, pmouseX + offset * 3, pmouseY)
  
colorMode(RGB, 255, 255, 255)

  strokeWeight(2)
  ellipse(400, 200, radius, radius)
  rect(a, b, w, h)
  rect(aa, b, w, h)
  
  
}

function mouseClicked() {
  
  var d = dist(mouseX, mouseY, 400, 200)
 // if cursor is within circle and mouse is clicked
  if (d < radius) {
    radius = 100
    radius++
    fill (255, 0, 0)
  }
}