var x = 50;
var y = 50;
let go = [];
let drop = [];
function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(255);
  
colorMode (RGB, 255, 255, 255);
  
fill(255, 140, 0);
go[0] = ellipse (x, 50, 25, 25);
go[1] = ellipse (x, 100, 25, 25);
go[2] = ellipse (x, 150, 25, 25);
go[3] = ellipse (mouseX, mouseY, 25, 25);
  
print (go.length);
  
  
for (let i = 0; i < go.length; i ++) {
  x++
}
  
fill(0, 0, 0);
drop[0] = ellipse (300, y, 25, 25);
drop[1] = ellipse (350, y, 25, 25);
drop[2] = ellipse (400, y, 25, 25);
drop[3] = ellipse (450, y, 25, 25);
  
line(50, 250, x, 50);
line(50, 250, x, 100);
line(50, 250, x, 150);
line(50, 250, mouseX, mouseY);
  

for (let ii = 0; ii < drop.length; ii ++) {
  y++
}
}