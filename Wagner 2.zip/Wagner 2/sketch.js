function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  
strokeWeight(3)
  line(100, 0, 100, 400)
  line(200, 0, 200, 400)
  line(300, 0, 300, 400)
  line(0, 100, 400, 100)
  line(0, 200, 400, 200)
  line(0, 300, 400, 300)
  
  
strokeWeight(1)
  colorMode(RGB, 255, 255, 255, 1)
  
 
  fill(255, 0, 0, 1)
  ellipse (50, 50, 75, 75)
  line(50, 85, 50, 160)
  
  fill(0, 255, 0, 21)
  ellipse(150, 150, 75, 75)
  line(150, 185, 150, 215)
  
  fill(0, 0, 255, 41)
  ellipse(250, 350, 75, 75)
  line(250, 385, 250, 400)
  
  fill(10, 140, 0, 55)
  arc(150, 250, 75, 75, 3.14, 1.57)
  line(150, 250, 100, 300)
  
  fill(0, 25, 200, 5)
  quad(250, 125, 275, 150, 250, 175, 225, 150);
  line(250, 170, 250, 260)
  
  fill(0, 25, 0)
  triangle(350, 375, 325, 400, 375, 400)
}